import { Flower2, Building, Sun, TreePalm, DraftingCompass, Sprout, Waves } from 'lucide-react';

export const SPACES = [
    {
        slug: 'home-garden',
        value: 'home_garden',
        name: 'Home Garden',
        icon: Flower2,
        tagline: 'Your patch of earth, reimagined.',
        description:
            'Front yards, back gardens, and forgotten side plots. We design home gardens that match your light, soil, and appetite for upkeep — then build them to last.',
        seoTitle: 'Home Garden Design & Landscaping | Blossom Live',
        seoDescription:
            'Human-designed home gardens, reviewed by real horticulturists. Show us your garden and get a Greenprint with layout, plant palette, and honest costs in 48 hours.',
    },
    {
        slug: 'balcony',
        value: 'balcony',
        name: 'Balcony',
        icon: Building,
        tagline: 'Four square metres of possibility.',
        description:
            'Railings, wind, weight limits, and harsh afternoon sun — balconies have rules. We design within them: container palettes, vertical green, and seating that fits.',
        seoTitle: 'Balcony Garden Design | Blossom Live',
        seoDescription:
            'Turn a bare balcony into a living space. Human-reviewed balcony designs with container plants, vertical gardens, and seating — Greenprint in 48 hours.',
    },
    {
        slug: 'terrace',
        value: 'terrace',
        name: 'Terrace',
        icon: Sun,
        tagline: 'The room above your house.',
        description:
            'Terraces are outdoor rooms waiting to happen. Shade structures, planters that survive full sun, outdoor kitchens, and evening lighting — designed as one space.',
        seoTitle: 'Terrace Garden & Outdoor Living Design | Blossom Live',
        seoDescription:
            'Terrace gardens, shade structures, and outdoor living designed by humans. Send photos of your terrace and receive a full Greenprint in 48 hours.',
    },
    {
        slug: 'villa',
        value: 'villa',
        name: 'Villa',
        icon: TreePalm,
        tagline: 'Land that should work as hard as it looks.',
        description:
            'Full-property landscaping: arrival sequences, lawns, tree palettes, water, lighting, and irrigation. Designed as a system, built in phases you can budget.',
        seoTitle: 'Villa Landscaping & Estate Gardens | Blossom Live',
        seoDescription:
            'Complete villa landscaping — arrival, lawns, trees, water, and lighting as one system. Human-reviewed Greenprint with phased, honest costing.',
    },
    {
        slug: 'project',
        value: 'project',
        name: 'Project',
        icon: DraftingCompass,
        tagline: 'For sites with drawings and deadlines.',
        description:
            'Commercial plots, resorts, offices, and developments. We plug into your architect’s workflow and deliver planting plans, BOQs, and build supervision.',
        seoTitle: 'Commercial Landscape Projects | Blossom Live',
        seoDescription:
            'Landscape design for commercial projects and developments. Planting plans, BOQs, and build supervision that plug into your architect’s workflow.',
    },
    {
        slug: 'grow',
        value: 'grow',
        name: 'Grow',
        icon: Sprout,
        tagline: 'Food you grew tastes different.',
        description:
            'Kitchen gardens, raised beds, fruit trees, and hydroponic corners. We design edible spaces around what you actually eat and how much time you have.',
        seoTitle: 'Kitchen Gardens & Edible Landscaping | Blossom Live',
        seoDescription:
            'Grow your own food with a human-designed kitchen garden. Raised beds, fruit trees, and edible planting matched to your climate and schedule.',
    },
    {
        slug: 'aquascape',
        value: 'aquascape',
        name: 'Aquascape',
        icon: Waves,
        tagline: 'Water, done biologically right.',
        description:
            'Ponds, natural pools, and planted water features. We balance filtration, planting, and fish load so the water stays clear without a chemistry degree.',
        seoTitle: 'Ponds, Natural Pools & Aquascaping | Blossom Live',
        seoDescription:
            'Biologically balanced ponds and aquascapes. Human-reviewed designs for clear, living water — Greenprint with costs in 48 hours.',
    },
];

export const getSpaceBySlug = (slug) => SPACES.find((s) => s.slug === slug);
export const getSpaceByValue = (value) => SPACES.find((s) => s.value === value);
