import React, { useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
    ArrowLeft, ArrowRight, Check, CloudSun, ImagePlus, Leaf, Loader2, PartyPopper,
    Sun, TreeDeciduous, UploadCloud, Video, X,
} from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { SPACES } from '@/data/spaces';

const VISION_OPTIONS = [
    'Plants', 'Outdoor living', 'Pet-friendly', 'Water features', 'Seating',
    'Shade', 'Privacy', 'Edible garden', 'Meditation space', 'Entertainment',
];

const MAINTENANCE = [
    { value: 1, label: 'Low', desc: 'Water it when I remember. Tough plants only.' },
    { value: 2, label: 'Moderate', desc: 'A weekend ritual is fine by me.' },
    { value: 3, label: 'High', desc: 'I enjoy the work. Pruning is therapy.' },
    { value: 4, label: 'Obsessed', desc: 'I talk to my plants. They answer.' },
];

const BUDGETS = [
    { value: '5k_15k', label: '₹5K – ₹15K', desc: 'A strong start' },
    { value: '15k_30k', label: '₹15K – ₹30K', desc: 'A real transformation' },
    { value: '30k_50k', label: '₹30K – ₹50K', desc: 'A full redesign' },
    { value: '50k_75k', label: '₹50K – ₹75K', desc: 'A statement space' },
    { value: '75k_plus', label: '₹75K+', desc: 'The whole vision' },
];

const SUNLIGHT = [
    { value: 'full_sun', label: 'Full sun', icon: Sun, desc: '6+ hours of direct light' },
    { value: 'partial_shade', label: 'Partial shade', icon: CloudSun, desc: 'Morning sun, afternoon relief' },
    { value: 'full_shade', label: 'Full shade', icon: TreeDeciduous, desc: 'Little to no direct sun' },
];

const STEP_TITLES = ['Space', 'Vision', 'Reality & Budget', 'Contact & Review'];

const Journey = ({ initialSpace = '' }) => {
    const [step, setStep] = useState(0);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState('');
    const [result, setResult] = useState(null);
    const fileInputRef = useRef(null);
    const videoInputRef = useRef(null);

    const [form, setForm] = useState({
        spaceType: initialSpace,
        photos: [],
        video: null,
        lengthM: '',
        widthM: '',
        vision: [],
        maintenance: 2,
        budget: '',
        location: '',
        sunlight: '',
        name: '',
        email: '',
        phone: '',
        humanReview: true,
    });

    const set = (patch) => setForm((f) => ({ ...f, ...patch }));

    const addPhotos = (files) => {
        const imgs = Array.from(files).filter((f) => f.type.startsWith('image/'));
        set({ photos: [...form.photos, ...imgs].slice(0, 6) });
    };

    const toggleVision = (v) =>
        set({ vision: form.vision.includes(v) ? form.vision.filter((x) => x !== v) : [...form.vision, v] });

    const canNext = useMemo(() => {
        if (step === 0) return form.spaceType && form.photos.length > 0 && Number(form.lengthM) > 0 && Number(form.widthM) > 0;
        if (step === 1) return form.vision.length > 0;
        if (step === 2) return form.budget && form.location.trim() && form.sunlight;
        if (step === 3) return form.name.trim() && /.+@.+\..+/.test(form.email);
        return true;
    }, [step, form]);

    const submit = async () => {
        setSubmitting(true);
        setError('');
        try {
            const fd = new FormData();
            fd.append('name', form.name.trim());
            fd.append('email', form.email.trim());
            fd.append('phone', form.phone.trim());
            fd.append('space_type', form.spaceType);
            form.photos.forEach((p) => fd.append('photos', p));
            if (form.video) fd.append('video', form.video);
            fd.append('length_m', String(form.lengthM));
            fd.append('width_m', String(form.widthM));
            fd.append('vision', JSON.stringify(form.vision));
            fd.append('maintenance', String(form.maintenance));
            fd.append('budget', form.budget);
            fd.append('location', form.location.trim());
            fd.append('sunlight', form.sunlight);
            const rec = await pb.collection('submissions').create(fd);
            setResult(rec);
        } catch (err) {
            setError(err?.message || 'Something went wrong. Please try again.');
        } finally {
            setSubmitting(false);
        }
    };

    const spaceName = SPACES.find((s) => s.value === form.spaceType)?.name || '';

    if (result) {
        return (
            <div className="mx-auto max-w-2xl">
                <motion.div
                    initial={{ opacity: 0, y: 24, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                    className="overflow-hidden rounded-3xl border border-border bg-card shadow-xl"
                >
                    <div className="bg-primary px-8 py-10 text-center text-primary-foreground">
                        <PartyPopper className="mx-auto h-10 w-10" />
                        <h3 className="mt-4 text-3xl font-bold tracking-display">We've got it.</h3>
                        <p className="mt-2 text-sm text-primary-foreground/80">
                            Your space is being reviewed by our team. Expect a Greenprint in 24–48 hours.
                        </p>
                    </div>
                    <div className="px-8 py-8">
                        <div className="rounded-2xl border border-dashed border-primary/40 bg-secondary/50 px-6 py-5 text-center">
                            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Your project ID</p>
                            <p className="mt-1 font-mono text-2xl font-bold text-primary">{result.project_id}</p>
                            <p className="mt-1 text-xs text-muted-foreground">A human — not a bot — is on the other end of this number.</p>
                        </div>
                        <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
                            <div><dt className="text-muted-foreground">Space</dt><dd className="font-medium">{spaceName}</dd></div>
                            <div><dt className="text-muted-foreground">Size</dt><dd className="font-medium">{form.lengthM}m × {form.widthM}m</dd></div>
                            <div><dt className="text-muted-foreground">Vision</dt><dd className="font-medium">{form.vision.slice(0, 3).join(', ')}{form.vision.length > 3 ? ` +${form.vision.length - 3}` : ''}</dd></div>
                            <div><dt className="text-muted-foreground">Budget</dt><dd className="font-medium">{BUDGETS.find((b) => b.value === form.budget)?.label}</dd></div>
                        </dl>
                        <p className="mt-6 text-center text-sm text-muted-foreground">
                            Confirmation sent to <span className="font-medium text-foreground">{form.email}</span>
                        </p>
                    </div>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="mx-auto max-w-2xl">
            {/* Progress */}
            <div className="mb-8">
                <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    <span>Step {step + 1} of 4</span>
                    <span>{STEP_TITLES[step]}</span>
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted">
                    <motion.div
                        className="h-full rounded-full bg-primary"
                        animate={{ width: `${((step + 1) / 4) * 100}%` }}
                        transition={{ duration: 0.4, ease: 'easeOut' }}
                    />
                </div>
            </div>

            <div className="rounded-3xl border border-border bg-card p-6 shadow-lg sm:p-10">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={step}
                        initial={{ opacity: 0, x: 32 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -32 }}
                        transition={{ duration: 0.28, ease: 'easeOut' }}
                    >
                        {step === 0 && (
                            <div>
                                <h3 className="text-2xl font-bold tracking-display">Help us see what you see.</h3>
                                <p className="mt-1 text-sm text-muted-foreground">Photos, rough dimensions, and a video if you have one.</p>

                                <div className="mt-6 flex flex-wrap gap-2">
                                    {SPACES.map((s) => (
                                        <button
                                            key={s.value}
                                            onClick={() => set({ spaceType: s.value })}
                                            className={`rounded-full border px-4 py-2 text-sm font-medium transition-all active:scale-[0.97] ${
                                                form.spaceType === s.value
                                                    ? 'border-primary bg-primary text-primary-foreground'
                                                    : 'border-border bg-background text-foreground hover:border-primary/50'
                                            }`}
                                        >
                                            {s.name}
                                        </button>
                                    ))}
                                </div>

                                <div
                                    onClick={() => fileInputRef.current?.click()}
                                    onDragOver={(e) => e.preventDefault()}
                                    onDrop={(e) => { e.preventDefault(); addPhotos(e.dataTransfer.files); }}
                                    className="mt-6 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-input bg-background px-6 py-10 text-center transition-colors hover:border-primary/60"
                                >
                                    <ImagePlus className="h-8 w-8 text-primary" />
                                    <p className="mt-3 text-sm font-medium">Drop photos here, or click to browse</p>
                                    <p className="mt-1 text-xs text-muted-foreground">Up to 6 photos of your space as it is today</p>
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        accept="image/*"
                                        multiple
                                        className="hidden"
                                        onChange={(e) => addPhotos(e.target.files)}
                                    />
                                </div>
                                {form.photos.length > 0 && (
                                    <div className="mt-4 flex flex-wrap gap-3">
                                        {form.photos.map((p, i) => (
                                            <div key={i} className="relative h-20 w-20 overflow-hidden rounded-xl border border-border">
                                                <img src={URL.createObjectURL(p)} alt="" className="h-full w-full object-cover" />
                                                <button
                                                    onClick={() => set({ photos: form.photos.filter((_, j) => j !== i) })}
                                                    className="absolute right-1 top-1 rounded-full bg-foreground/70 p-0.5 text-background"
                                                    aria-label="Remove photo"
                                                >
                                                    <X className="h-3 w-3" />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                <div className="mt-6 grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-medium">Length (m)</label>
                                        <input
                                            type="number" min="0.1" step="0.1" value={form.lengthM}
                                            onChange={(e) => set({ lengthM: e.target.value })}
                                            className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                            placeholder="e.g. 4.5"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium">Width (m)</label>
                                        <input
                                            type="number" min="0.1" step="0.1" value={form.widthM}
                                            onChange={(e) => set({ widthM: e.target.value })}
                                            className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                            placeholder="e.g. 2.2"
                                        />
                                    </div>
                                </div>

                                <button
                                    onClick={() => videoInputRef.current?.click()}
                                    className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                                >
                                    {form.video ? <Video className="h-4 w-4" /> : <UploadCloud className="h-4 w-4" />}
                                    {form.video ? form.video.name : 'Optional: add a video walkthrough'}
                                </button>
                                <input
                                    ref={videoInputRef}
                                    type="file"
                                    accept="video/mp4,video/quicktime,video/webm"
                                    className="hidden"
                                    onChange={(e) => set({ video: e.target.files?.[0] || null })}
                                />
                            </div>
                        )}

                        {step === 1 && (
                            <div>
                                <h3 className="text-2xl font-bold tracking-display">What makes a space feel like yours?</h3>
                                <p className="mt-1 text-sm text-muted-foreground">Pick everything that pulls you in.</p>
                                <div className="mt-6 flex flex-wrap gap-2.5">
                                    {VISION_OPTIONS.map((v) => {
                                        const active = form.vision.includes(v);
                                        return (
                                            <button
                                                key={v}
                                                onClick={() => toggleVision(v)}
                                                className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2.5 text-sm font-medium transition-all active:scale-[0.97] ${
                                                    active
                                                        ? 'border-primary bg-primary text-primary-foreground'
                                                        : 'border-border bg-background hover:border-primary/50'
                                                }`}
                                            >
                                                {active && <Check className="h-3.5 w-3.5" />}
                                                {v}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {step === 2 && (
                            <div>
                                <h3 className="text-2xl font-bold tracking-display">Plants are beautiful. Biology is less negotiable.</h3>
                                <p className="mt-1 text-sm text-muted-foreground">Be honest — we'll design around your reality, not a fantasy.</p>

                                <p className="mt-7 text-sm font-semibold">How much maintenance feels right?</p>
                                <input
                                    type="range" min="1" max="4" step="1" value={form.maintenance}
                                    onChange={(e) => set({ maintenance: Number(e.target.value) })}
                                    className="mt-3 w-full accent-[#1B4D3E]"
                                />
                                <div className="mt-1 flex justify-between text-xs font-medium text-muted-foreground">
                                    {MAINTENANCE.map((m) => (
                                        <span key={m.value} className={form.maintenance === m.value ? 'text-primary' : ''}>{m.label}</span>
                                    ))}
                                </div>
                                <p className="mt-2 rounded-xl bg-secondary/60 px-4 py-3 text-sm text-secondary-foreground">
                                    {MAINTENANCE.find((m) => m.value === form.maintenance)?.desc}
                                </p>

                                <p className="mt-7 text-sm font-semibold">Budget comfort</p>
                                <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                                    {BUDGETS.map((b) => (
                                        <button
                                            key={b.value}
                                            onClick={() => set({ budget: b.value })}
                                            className={`rounded-2xl border px-4 py-3.5 text-left transition-all active:scale-[0.98] ${
                                                form.budget === b.value
                                                    ? 'border-primary bg-primary text-primary-foreground'
                                                    : 'border-border bg-background hover:border-primary/50'
                                            }`}
                                        >
                                            <span className="block text-sm font-bold">{b.label}</span>
                                            <span className={`mt-0.5 block text-xs ${form.budget === b.value ? 'text-primary-foreground/75' : 'text-muted-foreground'}`}>{b.desc}</span>
                                        </button>
                                    ))}
                                </div>

                                <div className="mt-7">
                                    <label className="text-sm font-semibold">Location</label>
                                    <input
                                        type="text" value={form.location}
                                        onChange={(e) => set({ location: e.target.value })}
                                        className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                        placeholder="City or area — for climate intelligence"
                                    />
                                </div>

                                <p className="mt-7 text-sm font-semibold">How much sun does the space get?</p>
                                <div className="mt-3 grid grid-cols-3 gap-2.5">
                                    {SUNLIGHT.map((s) => (
                                        <button
                                            key={s.value}
                                            onClick={() => set({ sunlight: s.value })}
                                            className={`rounded-2xl border px-3 py-4 text-center transition-all active:scale-[0.98] ${
                                                form.sunlight === s.value
                                                    ? 'border-primary bg-primary text-primary-foreground'
                                                    : 'border-border bg-background hover:border-primary/50'
                                            }`}
                                        >
                                            <s.icon className="mx-auto h-5 w-5" />
                                            <span className="mt-2 block text-xs font-bold">{s.label}</span>
                                            <span className={`mt-0.5 block text-[11px] leading-tight ${form.sunlight === s.value ? 'text-primary-foreground/75' : 'text-muted-foreground'}`}>{s.desc}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {step === 3 && (
                            <div>
                                <h3 className="text-2xl font-bold tracking-display">Last step — where do we send your Greenprint?</h3>
                                <p className="mt-1 text-sm text-muted-foreground">
                                    We'll review your space personally and send a Greenprint with a project ID (e.g. BL-260823-014).
                                </p>
                                <div className="mt-6 space-y-4">
                                    <div>
                                        <label className="text-sm font-medium">Name</label>
                                        <input
                                            type="text" value={form.name}
                                            onChange={(e) => set({ name: e.target.value })}
                                            className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                            placeholder="Your name"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium">Email</label>
                                        <input
                                            type="email" value={form.email}
                                            onChange={(e) => set({ email: e.target.value })}
                                            className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                            placeholder="you@example.com"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium">Phone <span className="font-normal text-muted-foreground">(optional)</span></label>
                                        <input
                                            type="tel" value={form.phone}
                                            onChange={(e) => set({ phone: e.target.value })}
                                            className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                                            placeholder="+91 …"
                                        />
                                    </div>
                                    <label className="flex items-start gap-3 rounded-2xl border border-primary/30 bg-secondary/50 px-4 py-3.5">
                                        <input
                                            type="checkbox" checked={form.humanReview}
                                            onChange={(e) => set({ humanReview: e.target.checked })}
                                            className="mt-0.5 h-4 w-4 accent-[#1B4D3E]"
                                        />
                                        <span className="text-sm">
                                            <span className="font-semibold">I want human review of my space.</span>
                                            <span className="block text-xs text-muted-foreground">No auto-generated plans. A horticulturist reads every word.</span>
                                        </span>
                                    </label>
                                </div>
                                {error && <p className="mt-4 rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>}
                            </div>
                        )}
                    </motion.div>
                </AnimatePresence>

                <div className="mt-8 flex items-center justify-between">
                    <button
                        onClick={() => setStep((s) => Math.max(0, s - 1))}
                        disabled={step === 0}
                        className="inline-flex h-11 items-center gap-1.5 rounded-full px-5 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground disabled:opacity-0"
                    >
                        <ArrowLeft className="h-4 w-4" /> Back
                    </button>
                    {step < 3 ? (
                        <button
                            onClick={() => canNext && setStep((s) => s + 1)}
                            disabled={!canNext}
                            className="inline-flex h-11 items-center gap-1.5 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            Continue <ArrowRight className="h-4 w-4" />
                        </button>
                    ) : (
                        <button
                            onClick={submit}
                            disabled={!canNext || submitting}
                            className="inline-flex h-11 items-center gap-2 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition-all hover:scale-[1.02] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Leaf className="h-4 w-4" />}
                            {submitting ? 'Sending…' : 'Request my Greenprint'}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Journey;
