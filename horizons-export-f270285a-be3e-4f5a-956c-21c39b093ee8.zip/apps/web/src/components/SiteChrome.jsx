import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Leaf, ArrowRight } from 'lucide-react';

export const SiteHeader = ({ onStart }) => {
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const onScroll = () => setScrolled(window.scrollY > 24);
        onScroll();
        window.addEventListener('scroll', onScroll, { passive: true });
        return () => window.removeEventListener('scroll', onScroll);
    }, []);

    return (
        <header
            className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
                scrolled ? 'bg-background/90 backdrop-blur-md border-b border-border' : 'bg-transparent'
            }`}
        >
            <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
                <Link to="/" className="flex items-center gap-2 text-foreground">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                        <Leaf className="h-4 w-4" strokeWidth={2.2} />
                    </span>
                    <span className="text-lg font-bold tracking-display">Blossom Live</span>
                </Link>
                <nav className="hidden items-center gap-7 text-sm font-medium text-muted-foreground md:flex">
                    <a href="/#spaces" className="transition-colors hover:text-foreground">Spaces</a>
                    <a href="/#process" className="transition-colors hover:text-foreground">Process</a>
                    <a href="/#greenprint" className="transition-colors hover:text-foreground">For Architects</a>
                    <a href="/#trust" className="transition-colors hover:text-foreground">Why us</a>
                </nav>
                <button
                    onClick={onStart}
                    className="inline-flex h-10 items-center gap-1.5 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.03] active:scale-[0.98]"
                >
                    Start Your Journey
                    <ArrowRight className="h-4 w-4" />
                </button>
            </div>
        </header>
    );
};

export const SiteFooter = () => (
    <footer className="border-t border-border bg-secondary/40">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-3">
            <div>
                <div className="flex items-center gap-2">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                        <Leaf className="h-4 w-4" strokeWidth={2.2} />
                    </span>
                    <span className="text-lg font-bold tracking-display">Blossom Live</span>
                </div>
                <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
                    Beautiful is not enough. It has to work. Human-designed gardens, balconies, terraces, and living spaces.
                </p>
            </div>
            <div>
                <p className="text-sm font-semibold text-foreground">Spaces we design</p>
                <ul className="mt-3 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                    <li><a className="hover:text-foreground" href="/spaces/home-garden">Home Garden</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/balcony">Balcony</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/terrace">Terrace</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/villa">Villa</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/project">Project</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/grow">Grow</a></li>
                    <li><a className="hover:text-foreground" href="/spaces/aquascape">Aquascape</a></li>
                </ul>
            </div>
            <div>
                <p className="text-sm font-semibold text-foreground">Talk to a human</p>
                <p className="mt-3 text-sm text-muted-foreground">hello@blossom.live</p>
                <p className="mt-1 text-sm text-muted-foreground">Every submission is reviewed by a person. Project IDs keep it honest.</p>
            </div>
        </div>
        <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()} Blossom Live. Grown, not generated.
        </div>
    </footer>
);
