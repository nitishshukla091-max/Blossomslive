import React, { useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
    ArrowRight, BookOpen, Camera, Compass, DraftingCompass, Eye, HandCoins,
    Hammer, Leaf, Quote, Sprout,
} from 'lucide-react';
import Reveal from '@/components/Reveal';
import CountUp from '@/components/CountUp';
import Journey from '@/components/Journey';
import { SiteHeader, SiteFooter } from '@/components/SiteChrome';
import { SPACES } from '@/data/spaces';

const LOOP = [
    { icon: Camera, title: 'Show', desc: 'Photos, dimensions, a walkthrough video. You show us the space as it is.' },
    { icon: Compass, title: 'Tell', desc: 'Vision, maintenance appetite, budget comfort. One question at a time.' },
    { icon: DraftingCompass, title: 'Design', desc: 'A human horticulturist draws your Greenprint — layout, palette, phasing.' },
    { icon: HandCoins, title: 'Cost', desc: 'An honest estimate inside your budget band. No surprises later.' },
    { icon: Hammer, title: 'Build', desc: 'Our crews execute the Greenprint, supervised against the plan.' },
    { icon: Sprout, title: 'Live', desc: 'Care schedules and check-ins so the space thrives, not just survives.' },
];

const SCALE = [
    { label: 'One plant', desc: 'A desk, a sill, a start.', size: 'h-40' },
    { label: 'A balcony', desc: 'Morning coffee, upgraded.', size: 'h-52' },
    { label: 'A garden', desc: 'Weekends have a new address.', size: 'h-64' },
    { label: 'An entire villa', desc: 'Land that works as hard as it looks.', size: 'h-80' },
];

const TIERS = [
    { name: 'Good', price: '₹5K – ₹30K', desc: 'A focused refresh: container palettes, soil repair, and plants matched to your light.', points: ['Greenprint lite', 'Plant palette + placement', 'Care schedule'] },
    { name: 'Better', price: '₹30K – ₹75K', desc: 'A full redesign: layout, seating, lighting, and planting built in one phase.', points: ['Full Greenprint', 'Build supervision', 'Irrigation basics'], featured: true },
    { name: 'Best', price: '₹75K+', desc: 'The whole vision: structures, water, mature trees, phased like a project.', points: ['Architect-grade plans', 'Dedicated project lead', 'Seasonal reviews'] },
];

const HomePage = () => {
    const [journeySpace, setJourneySpace] = useState('');
    const heroRef = useRef(null);
    const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
    const grown = useTransform(scrollYProgress, [0, 0.75], [0, 1]);
    const emptyOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0.15]);
    const gardenScale = useTransform(scrollYProgress, [0, 0.75], [0.6, 1]);
    const gardenOpacity = useTransform(scrollYProgress, [0.05, 0.7], [0, 1]);

    const startJourney = (spaceValue = '') => {
        if (spaceValue) setJourneySpace(spaceValue);
        document.getElementById('journey')?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <div className="bg-background text-foreground">
            <Helmet>
                <title>Blossom Live — Show Us Your Space. We'll Show You What's Possible.</title>
                <meta name="description" content="Human-designed gardens, balconies, terraces, and living spaces. Send photos of your space and get a Greenprint — layout, plant palette, and honest costs — in 48 hours." />
            </Helmet>

            <SiteHeader onStart={() => startJourney()} />

            {/* 1. HERO — scroll grows the garden */}
            <section ref={heroRef} className="relative h-[220vh]">
                <div className="sticky top-0 flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-5">
                    <motion.div style={{ opacity: emptyOpacity }} className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-muted to-transparent" />
                    {/* growing garden */}
                    <motion.div style={{ opacity: gardenOpacity, scale: gardenScale }} className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-center gap-6 pb-6">
                        {[...Array(9)].map((_, i) => (
                            <motion.div key={i} style={{ scaleY: grown }} className="origin-bottom">
                                {i % 3 === 0 ? (
                                    <Leaf className="h-16 w-16 text-primary/70 sm:h-24 sm:w-24" strokeWidth={1.2} />
                                ) : i % 3 === 1 ? (
                                    <Sprout className="h-12 w-12 text-primary/50 sm:h-16 sm:w-16" strokeWidth={1.2} />
                                ) : (
                                    <div className="h-20 w-10 rounded-t-full bg-accent/60 sm:h-28 sm:w-14" />
                                )}
                            </motion.div>
                        ))}
                    </motion.div>

                    <div className="relative z-10 mx-auto max-w-4xl text-center">
                        <motion.p
                            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                            className="text-xs font-bold uppercase tracking-[0.25em] text-primary"
                        >
                            Human-designed. Biologically sound.
                        </motion.p>
                        <motion.h1
                            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }}
                            className="mt-5 text-4xl font-extrabold leading-[1.05] tracking-display sm:text-6xl md:text-7xl"
                        >
                            Show us your space.<br />
                            <span className="text-primary">We'll show you what's possible.</span>
                        </motion.h1>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                            className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg"
                        >
                            From empty corners to thriving spaces. Scroll, and watch an empty plot grow — that's what we do, at your place.
                        </motion.p>
                        <motion.div
                            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
                            className="mt-9"
                        >
                            <button
                                onClick={() => startJourney()}
                                className="inline-flex h-14 items-center gap-2 rounded-full bg-primary px-9 text-base font-bold text-primary-foreground shadow-lg transition-transform hover:scale-[1.04] active:scale-[0.98]"
                            >
                                Start Your Journey <ArrowRight className="h-5 w-5" />
                            </button>
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* 2. SPACE SELECTION */}
            <section id="spaces" className="mx-auto max-w-6xl px-5 py-24">
                <Reveal>
                    <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Where do we begin?</p>
                    <h2 className="mt-3 max-w-2xl text-3xl font-extrabold tracking-display sm:text-5xl">Pick your space. We'll handle the rest.</h2>
                </Reveal>
                <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                    {SPACES.map((s, i) => (
                        <Reveal key={s.value} delay={i * 0.05}>
                            <button
                                onClick={() => startJourney(s.value)}
                                className="group flex h-full w-full flex-col items-start rounded-3xl border border-border bg-card p-6 text-left transition-all hover:-translate-y-1 hover:border-primary/50 hover:shadow-xl active:scale-[0.98]"
                            >
                                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                                    <s.icon className="h-6 w-6" strokeWidth={1.8} />
                                </span>
                                <span className="mt-4 text-lg font-bold">{s.name}</span>
                                <span className="mt-1 text-sm leading-snug text-muted-foreground">{s.tagline}</span>
                                <Link
                                    to={`/spaces/${s.slug}`}
                                    onClick={(e) => e.stopPropagation()}
                                    className="mt-3 text-xs font-semibold text-primary hover:underline"
                                >
                                    Learn more →
                                </Link>
                            </button>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* 3. JOURNEY */}
            <section id="journey" className="border-y border-border bg-secondary/30 py-24">
                <div className="mx-auto max-w-6xl px-5">
                    <Reveal className="mb-12 text-center">
                        <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">The journey</p>
                        <h2 className="mt-3 text-3xl font-extrabold tracking-display sm:text-5xl">Four steps. Zero friction.</h2>
                        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">One question at a time. No boring forms, no corporate nursery energy.</p>
                    </Reveal>
                    <Journey key={journeySpace || 'default'} initialSpace={journeySpace} />
                </div>
            </section>

            {/* 5. LOOP */}
            <section id="process" className="mx-auto max-w-6xl px-5 py-24">
                <Reveal>
                    <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">The Blossom loop</p>
                    <h2 className="mt-3 max-w-2xl text-3xl font-extrabold tracking-display sm:text-5xl">Show → Tell → Design → Cost → Build → Live</h2>
                </Reveal>
                <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {LOOP.map((l, i) => (
                        <Reveal key={l.title} delay={i * 0.06}>
                            <div className="group relative h-full overflow-hidden rounded-3xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:shadow-xl">
                                <span className="absolute right-5 top-5 font-mono text-xs font-bold text-muted-foreground">0{i + 1}</span>
                                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                                    <l.icon className="h-5 w-5" strokeWidth={1.8} />
                                </span>
                                <h3 className="mt-4 text-xl font-bold">{l.title}</h3>
                                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{l.desc}</p>
                            </div>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* 6. SCALE */}
            <section className="border-y border-border bg-primary py-24 text-primary-foreground">
                <div className="mx-auto max-w-6xl px-5">
                    <Reveal>
                        <h2 className="max-w-2xl text-3xl font-extrabold tracking-display sm:text-5xl">From one plant to an entire space.</h2>
                        <p className="mt-4 max-w-xl text-primary-foreground/75">Whatever your space, we scale the approach — the same care, the same biology, any footprint.</p>
                    </Reveal>
                    <div className="mt-14 flex flex-wrap items-end justify-center gap-6">
                        {SCALE.map((s, i) => (
                            <Reveal key={s.label} delay={i * 0.08} className="flex flex-col items-center">
                                <div className={`flex ${s.size} w-40 flex-col justify-end rounded-t-full bg-primary-foreground/10 p-4 backdrop-blur-sm sm:w-48`}>
                                    <Sprout className="mx-auto text-accent" style={{ height: 24 + i * 14, width: 24 + i * 14 }} strokeWidth={1.5} />
                                </div>
                                <p className="mt-4 font-bold">{s.label}</p>
                                <p className="text-sm text-primary-foreground/70">{s.desc}</p>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </section>

            {/* 7. GOOD / BETTER / BEST */}
            <section className="mx-auto max-w-6xl px-5 py-24">
                <Reveal className="text-center">
                    <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Scope, honestly priced</p>
                    <h2 className="mt-3 text-3xl font-extrabold tracking-display sm:text-5xl">Good. Better. Best.</h2>
                </Reveal>
                <div className="mt-12 grid gap-5 md:grid-cols-3">
                    {TIERS.map((t, i) => (
                        <Reveal key={t.name} delay={i * 0.08}>
                            <div className={`flex h-full flex-col rounded-3xl border p-8 transition-all hover:-translate-y-1 hover:shadow-xl ${
                                t.featured ? 'border-primary bg-primary text-primary-foreground shadow-lg' : 'border-border bg-card'
                            }`}>
                                <p className={`text-xs font-bold uppercase tracking-widest ${t.featured ? 'text-primary-foreground/70' : 'text-primary'}`}>{t.name}</p>
                                <p className="mt-3 text-3xl font-extrabold tracking-display">{t.price}</p>
                                <p className={`mt-3 text-sm leading-relaxed ${t.featured ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>{t.desc}</p>
                                <ul className="mt-6 space-y-2.5 text-sm">
                                    {t.points.map((p) => (
                                        <li key={p} className="flex items-center gap-2">
                                            <Leaf className={`h-4 w-4 ${t.featured ? 'text-accent' : 'text-primary'}`} /> {p}
                                        </li>
                                    ))}
                                </ul>
                                <button
                                    onClick={() => startJourney()}
                                    className={`mt-8 inline-flex h-11 items-center justify-center rounded-full text-sm font-bold transition-transform hover:scale-[1.02] active:scale-[0.98] ${
                                        t.featured ? 'bg-primary-foreground text-primary' : 'bg-primary text-primary-foreground'
                                    }`}
                                >
                                    Start with {t.name}
                                </button>
                            </div>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* 8. GREENPRINT */}
            <section id="greenprint" className="border-y border-border bg-secondary/30 py-24">
                <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 md:grid-cols-2">
                    <Reveal>
                        <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">For architects & developers</p>
                        <h2 className="mt-3 text-3xl font-extrabold tracking-display sm:text-5xl">Meet your Greenprint.</h2>
                        <p className="mt-5 leading-relaxed text-muted-foreground">
                            Every Blossom project — from a balcony to a resort — runs on a Greenprint: a human-drawn plan with layout direction,
                            a plant palette matched to light and climate, phased BOQs, and build supervision notes. It plugs straight into your
                            drawings and deadlines.
                        </p>
                        <p className="mt-4 leading-relaxed text-muted-foreground">
                            Send us a site, get a document your contractors can actually build from. Project IDs keep every revision traceable.
                        </p>
                        <button
                            onClick={() => startJourney('project')}
                            className="mt-8 inline-flex h-12 items-center gap-2 rounded-full bg-primary px-7 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.03] active:scale-[0.98]"
                        >
                            Partner with us <ArrowRight className="h-4 w-4" />
                        </button>
                    </Reveal>
                    <Reveal delay={0.15}>
                        <div className="rounded-3xl border border-border bg-card p-8 shadow-lg">
                            <div className="flex items-center justify-between border-b border-dashed border-border pb-4">
                                <span className="font-mono text-sm font-bold text-primary">BL-260823-014</span>
                                <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground">Greenprint v2</span>
                            </div>
                            <div className="mt-5 space-y-3 text-sm">
                                {['Layout direction & zoning', 'Plant palette — 14 species, climate-matched', 'Irrigation & drainage notes', 'Phased BOQ within ₹30K–₹50K band', 'Build supervision checklist'].map((row) => (
                                    <div key={row} className="flex items-center gap-3 rounded-xl bg-background px-4 py-3">
                                        <Eye className="h-4 w-4 shrink-0 text-primary" />
                                        <span className="font-medium">{row}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* 9. DIY & KNOWLEDGE */}
            <section className="mx-auto max-w-6xl px-5 py-24">
                <div className="grid items-center gap-10 md:grid-cols-[1.2fr_1fr]">
                    <Reveal>
                        <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">DIY & knowledge engine</p>
                        <h2 className="mt-3 text-3xl font-extrabold tracking-display sm:text-4xl">Want to get your hands dirty first?</h2>
                        <p className="mt-4 max-w-lg leading-relaxed text-muted-foreground">
                            Plant care guides, design principles, and seasonal advice — written by the same humans who design our projects.
                            Learn why your monstera is sulking before you book anyone.
                        </p>
                        <a href="#journey" onClick={(e) => { e.preventDefault(); startJourney(); }}
                            className="mt-7 inline-flex items-center gap-2 text-sm font-bold text-primary hover:underline">
                            Explore the knowledge base <BookOpen className="h-4 w-4" />
                        </a>
                    </Reveal>
                    <Reveal delay={0.1}>
                        <div className="space-y-3">
                            {['Why plants die in "low light" corners', 'The 3-layer planting rule for balconies', 'Monsoon prep: a 20-minute checklist'].map((t) => (
                                <div key={t} className="flex items-center gap-4 rounded-2xl border border-border bg-card px-5 py-4 transition-all hover:-translate-y-0.5 hover:shadow-md">
                                    <BookOpen className="h-5 w-5 shrink-0 text-primary" />
                                    <span className="text-sm font-semibold">{t}</span>
                                </div>
                            ))}
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* 10. TRUST */}
            <section id="trust" className="border-y border-border bg-card py-24">
                <div className="mx-auto max-w-6xl px-5">
                    <Reveal className="text-center">
                        <h2 className="text-3xl font-extrabold tracking-display sm:text-5xl">Beautiful is not enough. It has to work.</h2>
                        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                            Every space is reviewed by a human horticulturist. Every plant is chosen for your light, your water, your climate — not a catalog photo.
                        </p>
                    </Reveal>
                    <div className="mt-14 grid grid-cols-2 gap-6 text-center md:grid-cols-4">
                        {[
                            { v: 240, suffix: '+', label: 'Projects completed' },
                            { v: 12000, suffix: '+', label: 'Plants thriving' },
                            { v: 48, suffix: 'h', label: 'Greenprint turnaround' },
                            { v: 100, suffix: '%', label: 'Human-reviewed' },
                        ].map((s) => (
                            <Reveal key={s.label}>
                                <p className="text-4xl font-extrabold tracking-display text-primary sm:text-5xl">
                                    <CountUp value={s.v} suffix={s.suffix} />
                                </p>
                                <p className="mt-2 text-sm font-medium text-muted-foreground">{s.label}</p>
                            </Reveal>
                        ))}
                    </div>
                    <Reveal delay={0.1} className="mx-auto mt-14 max-w-2xl">
                        <figure className="rounded-3xl border border-border bg-background p-8 text-center">
                            <Quote className="mx-auto h-6 w-6 text-primary" />
                            <blockquote className="mt-4 text-lg font-medium leading-relaxed">
                                "They told me two of my dream plants would die on my balcony — then gave me three that would thrive. That honesty is why I hired them."
                            </blockquote>
                            <figcaption className="mt-4 text-sm text-muted-foreground">Meera K. — Balcony, BL-260711-003</figcaption>
                        </figure>
                    </Reveal>
                </div>
            </section>

            {/* 11. FINAL CTA */}
            <section className="py-28 text-center">
                <Reveal>
                    <h2 className="mx-auto max-w-3xl px-5 text-4xl font-extrabold tracking-display sm:text-6xl">
                        Ready to transform <span className="text-primary">your space?</span>
                    </h2>
                    <button
                        onClick={() => startJourney()}
                        className="mt-10 inline-flex h-14 items-center gap-2 rounded-full bg-primary px-10 text-base font-bold text-primary-foreground shadow-xl transition-transform hover:scale-[1.05] active:scale-[0.98]"
                    >
                        Start Your Journey <ArrowRight className="h-5 w-5" />
                    </button>
                </Reveal>
            </section>

            <SiteFooter />

            {/* Mobile sticky CTA */}
            <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 p-3 backdrop-blur-md md:hidden">
                <button
                    onClick={() => startJourney()}
                    className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-bold text-primary-foreground active:scale-[0.98]"
                >
                    Start Your Journey <ArrowRight className="h-4 w-4" />
                </button>
            </div>
        </div>
    );
};

export default HomePage;
