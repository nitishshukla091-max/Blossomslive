import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Leaf, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const AdminLoginPage = () => {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            await login(email, password);
            navigate('/admin', { replace: true });
        } catch {
            setError('Invalid email or password.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex min-h-[100dvh] items-center justify-center bg-background px-5">
            <Helmet>
                <title>Admin Login | Blossom Live</title>
                <meta name="description" content="Blossom Live team login to review space submissions and Greenprints." />
            </Helmet>
            <form onSubmit={onSubmit} className="w-full max-w-sm rounded-3xl border border-border bg-card p-8 shadow-lg">
                <div className="flex items-center gap-2">
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                        <Leaf className="h-4 w-4" />
                    </span>
                    <span className="text-lg font-bold tracking-display">Blossom Live</span>
                </div>
                <h1 className="mt-6 text-2xl font-bold tracking-display">Team login</h1>
                <p className="mt-1 text-sm text-muted-foreground">Review submissions and Greenprints.</p>

                <label className="mt-6 block text-sm font-medium">Email</label>
                <input
                    type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                    className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                    placeholder="you@blossom.live"
                />
                <label className="mt-4 block text-sm font-medium">Password</label>
                <input
                    type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                    className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
                    placeholder="••••••••"
                />
                {error && <p className="mt-4 rounded-xl bg-destructive/10 px-4 py-2.5 text-sm text-destructive">{error}</p>}
                <button
                    type="submit" disabled={loading}
                    className="mt-6 flex h-11 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.01] active:scale-[0.98] disabled:opacity-50"
                >
                    {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                    Sign in
                </button>
            </form>
        </div>
    );
};

export default AdminLoginPage;
