import React from 'react';
import { Helmet } from 'react-helmet';
import { Navigate, useParams } from 'react-router-dom';
import { ArrowRight, Check, Leaf } from 'lucide-react';
import Reveal from '@/components/Reveal';
import Journey from '@/components/Journey';
import { SiteHeader, SiteFooter } from '@/components/SiteChrome';
import { getSpaceBySlug, SPACES } from '@/data/spaces';

const SpaceLandingPage = () => {
    const { slug } = useParams();
    const space = getSpaceBySlug(slug);

    if (!space) return <Navigate to="/" replace />;

    const Icon = space.icon;

    const startJourney = () => document.getElementById('journey')?.scrollIntoView({ behavior: 'smooth' });

    return (
        <div className="bg-background text-foreground">
            <Helmet>
                <title>{space.seoTitle}</title>
                <meta name="description" content={space.seoDescription} />
            </Helmet>

            <SiteHeader onStart={startJourney} />

            <section className="flex min-h-[80dvh] items-center px-5 pb-16 pt-32">
                <div className="mx-auto grid w-full max-w-6xl items-center gap-12 md:grid-cols-2">
                    <Reveal>
                        <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Blossom Live / {space.name}</p>
                        <h1 className="mt-4 text-4xl font-extrabold leading-[1.05] tracking-display sm:text-6xl">
                            {space.tagline}
                        </h1>
                        <p className="mt-6 max-w-lg leading-relaxed text-muted-foreground">{space.description}</p>
                        <button
                            onClick={startJourney}
                            className="mt-9 inline-flex h-13 items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-bold text-primary-foreground shadow-lg transition-transform hover:scale-[1.04] active:scale-[0.98]"
                        >
                            Show us your {space.name.toLowerCase()} <ArrowRight className="h-5 w-5" />
                        </button>
                    </Reveal>
                    <Reveal delay={0.15}>
                        <div className="flex aspect-square items-center justify-center rounded-[3rem] border border-border bg-gradient-to-br from-secondary via-card to-accent/30">
                            <Icon className="h-32 w-32 text-primary/60" strokeWidth={0.9} />
                        </div>
                    </Reveal>
                </div>
            </section>

            <section className="border-y border-border bg-card py-20">
                <div className="mx-auto max-w-6xl px-5">
                    <Reveal>
                        <h2 className="text-2xl font-extrabold tracking-display sm:text-4xl">What your Greenprint covers</h2>
                    </Reveal>
                    <div className="mt-10 grid gap-4 sm:grid-cols-2">
                        {[
                            'Layout direction drawn by a human horticulturist',
                            'Plant palette matched to your light and climate',
                            'Honest cost estimate inside your budget band',
                            'Care schedule so it thrives after we leave',
                        ].map((item, i) => (
                            <Reveal key={item} delay={i * 0.06}>
                                <div className="flex items-start gap-3 rounded-2xl border border-border bg-background p-5">
                                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                                        <Check className="h-3.5 w-3.5" />
                                    </span>
                                    <p className="text-sm font-medium leading-relaxed">{item}</p>
                                </div>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </section>

            <section id="journey" className="bg-secondary/30 py-24">
                <div className="mx-auto max-w-6xl px-5">
                    <Reveal className="mb-12 text-center">
                        <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">Start here</p>
                        <h2 className="mt-3 text-3xl font-extrabold tracking-display sm:text-4xl">
                            Show us your {space.name.toLowerCase()}.
                        </h2>
                        <p className="mx-auto mt-4 max-w-md text-muted-foreground">
                            Four quick steps. A human reviews everything and replies with a Greenprint in 24–48 hours.
                        </p>
                    </Reveal>
                    <Journey initialSpace={space.value} />
                </div>
            </section>

            <section className="mx-auto max-w-6xl px-5 py-20">
                <Reveal>
                    <h2 className="text-xl font-extrabold tracking-display sm:text-2xl">Other spaces we design</h2>
                </Reveal>
                <div className="mt-8 flex flex-wrap gap-3">
                    {SPACES.filter((s) => s.slug !== slug).map((s) => (
                        <a
                            key={s.slug}
                            href={`/spaces/${s.slug}`}
                            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-5 py-2.5 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md"
                        >
                            <Leaf className="h-4 w-4 text-primary" /> {s.name}
                        </a>
                    ))}
                </div>
            </section>

            <SiteFooter />
        </div>
    );
};

export default SpaceLandingPage;
