import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Leaf, Loader2, LogOut, X } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { getSpaceByValue } from '@/data/spaces';

const STATUSES = [
    { value: 'new', label: 'New' },
    { value: 'in_review', label: 'In review' },
    { value: 'greenprint_sent', label: 'Greenprint sent' },
    { value: 'built', label: 'Built' },
];

const BUDGET_LABELS = {
    '5k_15k': '₹5K–₹15K', '15k_30k': '₹15K–₹30K', '30k_50k': '₹30K–₹50K',
    '50k_75k': '₹50K–₹75K', '75k_plus': '₹75K+',
};

const statusClass = (s) =>
    s === 'new' ? 'bg-amber-100 text-amber-800'
    : s === 'in_review' ? 'bg-blue-100 text-blue-800'
    : s === 'greenprint_sent' ? 'bg-emerald-100 text-emerald-800'
    : 'bg-secondary text-secondary-foreground';

const AdminDashboardPage = () => {
    const { user, logout } = useAuth();
    const [subs, setSubs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [filter, setFilter] = useState('all');
    const [active, setActive] = useState(null);

    const load = () => {
        setLoading(true);
        pb.collection('submissions')
            .getFullList({ sort: '-created' })
            .then(setSubs)
            .catch((e) => setError(e?.message || 'Failed to load submissions'))
            .finally(() => setLoading(false));
    };

    useEffect(load, []);

    const setStatus = async (id, status) => {
        const rec = await pb.collection('submissions').update(id, { status });
        setSubs((prev) => prev.map((s) => (s.id === id ? rec : s)));
        setActive((a) => (a && a.id === id ? rec : a));
    };

    const visible = filter === 'all' ? subs : subs.filter((s) => s.status === filter);

    return (
        <div className="min-h-[100dvh] bg-background">
            <Helmet>
                <title>Submissions Dashboard | Blossom Live</title>
                <meta name="description" content="Review Blossom Live space submissions, update statuses, and manage Greenprints." />
            </Helmet>

            <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-md">
                <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
                    <div className="flex items-center gap-2">
                        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" />
                        </span>
                        <span className="font-bold tracking-display">Blossom Live — Studio</span>
                    </div>
                    <div className="flex items-center gap-4">
                        <span className="hidden text-sm text-muted-foreground sm:block">{user?.email}</span>
                        <button onClick={logout} className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground">
                            <LogOut className="h-4 w-4" /> Log out
                        </button>
                    </div>
                </div>
            </header>

            <main className="mx-auto max-w-6xl px-5 py-8">
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <h1 className="text-2xl font-bold tracking-display">Submissions <span className="text-muted-foreground">({subs.length})</span></h1>
                    <div className="flex flex-wrap gap-2">
                        {[{ value: 'all', label: 'All' }, ...STATUSES].map((s) => (
                            <button
                                key={s.value}
                                onClick={() => setFilter(s.value)}
                                className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition-colors ${
                                    filter === s.value ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card hover:border-primary/50'
                                }`}
                            >
                                {s.label}
                            </button>
                        ))}
                    </div>
                </div>

                {loading ? (
                    <div className="flex justify-center py-24"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : error ? (
                    <p className="mt-8 rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>
                ) : visible.length === 0 ? (
                    <div className="mt-12 rounded-3xl border border-dashed border-border bg-card py-20 text-center">
                        <Leaf className="mx-auto h-8 w-8 text-muted-foreground" />
                        <p className="mt-3 font-semibold">No submissions yet</p>
                        <p className="text-sm text-muted-foreground">New journey completions will appear here.</p>
                    </div>
                ) : (
                    <div className="mt-6 overflow-hidden rounded-2xl border border-border bg-card">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="border-b border-border bg-secondary/40 text-xs uppercase tracking-wider text-muted-foreground">
                                    <tr>
                                        <th className="px-5 py-3 font-semibold">Project</th>
                                        <th className="px-5 py-3 font-semibold">Name</th>
                                        <th className="px-5 py-3 font-semibold">Space</th>
                                        <th className="px-5 py-3 font-semibold">Budget</th>
                                        <th className="px-5 py-3 font-semibold">Status</th>
                                        <th className="px-5 py-3 font-semibold">Received</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border">
                                    {visible.map((s) => (
                                        <tr key={s.id} onClick={() => setActive(s)} className="cursor-pointer transition-colors hover:bg-secondary/30">
                                            <td className="px-5 py-3.5 font-mono text-xs font-bold text-primary">{s.project_id || '—'}</td>
                                            <td className="px-5 py-3.5 font-medium">{s.name}</td>
                                            <td className="px-5 py-3.5">{getSpaceByValue(s.space_type)?.name || s.space_type}</td>
                                            <td className="px-5 py-3.5">{BUDGET_LABELS[s.budget] || '—'}</td>
                                            <td className="px-5 py-3.5">
                                                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusClass(s.status)}`}>
                                                    {STATUSES.find((x) => x.value === s.status)?.label || s.status}
                                                </span>
                                            </td>
                                            <td className="px-5 py-3.5 text-muted-foreground">{new Date(s.created).toLocaleDateString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </main>

            {active && (
                <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-0 sm:items-center sm:p-6" onClick={() => setActive(null)}>
                    <div
                        className="max-h-[90dvh] w-full max-w-2xl overflow-y-auto rounded-t-3xl bg-card p-6 shadow-2xl sm:rounded-3xl sm:p-8"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-start justify-between">
                            <div>
                                <p className="font-mono text-sm font-bold text-primary">{active.project_id}</p>
                                <h2 className="mt-1 text-2xl font-bold tracking-display">{active.name}</h2>
                                <p className="text-sm text-muted-foreground">{active.email}{active.phone ? ` · ${active.phone}` : ''}</p>
                            </div>
                            <button onClick={() => setActive(null)} className="rounded-full p-2 hover:bg-secondary" aria-label="Close">
                                <X className="h-5 w-5" />
                            </button>
                        </div>

                        <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-4 text-sm sm:grid-cols-3">
                            <div><dt className="text-xs text-muted-foreground">Space</dt><dd className="mt-0.5 font-medium">{getSpaceByValue(active.space_type)?.name}</dd></div>
                            <div><dt className="text-xs text-muted-foreground">Size</dt><dd className="mt-0.5 font-medium">{active.length_m}m × {active.width_m}m</dd></div>
                            <div><dt className="text-xs text-muted-foreground">Location</dt><dd className="mt-0.5 font-medium">{active.location || '—'}</dd></div>
                            <div><dt className="text-xs text-muted-foreground">Budget</dt><dd className="mt-0.5 font-medium">{BUDGET_LABELS[active.budget] || '—'}</dd></div>
                            <div><dt className="text-xs text-muted-foreground">Sunlight</dt><dd className="mt-0.5 font-medium">{(active.sunlight || '').replace(/_/g, ' ') || '—'}</dd></div>
                            <div><dt className="text-xs text-muted-foreground">Maintenance</dt><dd className="mt-0.5 font-medium">{['', 'Low', 'Moderate', 'High', 'Obsessed'][active.maintenance] || '—'}</dd></div>
                        </dl>

                        {Array.isArray(active.vision) && active.vision.length > 0 && (
                            <div className="mt-5">
                                <p className="text-xs text-muted-foreground">Vision</p>
                                <div className="mt-2 flex flex-wrap gap-2">
                                    {active.vision.map((v) => (
                                        <span key={v} className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground">{v}</span>
                                    ))}
                                </div>
                            </div>
                        )}

                        {Array.isArray(active.photos) && active.photos.length > 0 && (
                            <div className="mt-5">
                                <p className="text-xs text-muted-foreground">Photos</p>
                                <div className="mt-2 flex flex-wrap gap-3">
                                    {active.photos.map((p) => (
                                        <a key={p} href={pb.files.getURL(active, p)} target="_blank" rel="noreferrer">
                                            <img src={pb.files.getURL(active, p, { thumb: '120x120' })} alt="" className="h-20 w-20 rounded-xl border border-border object-cover" />
                                        </a>
                                    ))}
                                </div>
                            </div>
                        )}
                        {active.video && (
                            <a href={pb.files.getURL(active, active.video)} target="_blank" rel="noreferrer" className="mt-4 inline-block text-sm font-semibold text-primary hover:underline">
                                Watch video walkthrough →
                            </a>
                        )}

                        <div className="mt-7 border-t border-border pt-5">
                            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Update status</p>
                            <div className="mt-3 flex flex-wrap gap-2">
                                {STATUSES.map((s) => (
                                    <button
                                        key={s.value}
                                        onClick={() => setStatus(active.id, s.value)}
                                        className={`rounded-full border px-4 py-2 text-xs font-bold transition-all active:scale-[0.97] ${
                                            active.status === s.value
                                                ? 'border-primary bg-primary text-primary-foreground'
                                                : 'border-border hover:border-primary/50'
                                        }`}
                                    >
                                        {s.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminDashboardPage;
