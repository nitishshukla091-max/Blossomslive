/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId("submissions");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "submissions",
        // Public create (anonymous visitors submit the journey); only
        // authenticated team accounts can read or manage submissions.
        listRule: "@request.auth.id != ''",
        viewRule: "@request.auth.id != ''",
        createRule: "",
        updateRule: "@request.auth.id != ''",
        deleteRule: "@request.auth.id != ''",
        fields: [
          { name: "name", type: "text", required: true, max: 120 },
          { name: "email", type: "email", required: true },
          { name: "phone", type: "text", max: 30 },
          {
            name: "space_type",
            type: "select",
            required: true,
            maxSelect: 1,
            values: [
              "home_garden",
              "balcony",
              "terrace",
              "villa",
              "project",
              "grow",
              "aquascape",
            ],
          },
          {
            name: "photos",
            type: "file",
            maxSelect: 6,
            maxSize: 10485760,
            mimeTypes: [
              "image/jpeg",
              "image/png",
              "image/webp",
              "image/heic",
              "image/heif",
            ],
            thumbs: ["480x0", "120x120"],
          },
          {
            name: "video",
            type: "file",
            maxSelect: 1,
            maxSize: 52428800,
            mimeTypes: ["video/mp4", "video/quicktime", "video/webm"],
          },
          { name: "length_m", type: "number", required: true, min: 0.1, max: 100000 },
          { name: "width_m", type: "number", required: true, min: 0.1, max: 100000 },
          { name: "vision", type: "json" },
          { name: "maintenance", type: "number", min: 1, max: 5, onlyInt: true },
          {
            name: "budget",
            type: "select",
            maxSelect: 1,
            values: ["5k_15k", "15k_30k", "30k_50k", "50k_75k", "75k_plus"],
          },
          { name: "location", type: "text", max: 200 },
          {
            name: "sunlight",
            type: "select",
            maxSelect: 1,
            values: ["full_sun", "partial_shade", "full_shade"],
          },
          { name: "project_id", type: "text", max: 40 },
          {
            name: "status",
            type: "select",
            maxSelect: 1,
            values: ["new", "in_review", "greenprint_sent", "built"],
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_submissions_project_id ON submissions (project_id)",
          "CREATE INDEX idx_submissions_status ON submissions (status)",
          "CREATE INDEX idx_submissions_created ON submissions (created)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("submissions");
      app.delete(collection);
    } catch (e) {
      if (e.message.includes("no rows in result set")) {
        console.log("Collection not found, skipping revert");
        return;
      }
      throw e;
    }
  },
);
