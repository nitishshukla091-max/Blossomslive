/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Admin-only app: close public sign-up, accounts are provisioned here.
    users.createRule = null;
    app.save(users);

    let exists = true;
    try {
      app.findAuthRecordByEmail("users", "team@blossomlive.in");
    } catch (_) {
      exists = false;
    }

    if (!exists) {
      const admin = new Record(users);
      admin.set("email", "team@blossomlive.in");
      admin.set("password", "BlossomLive#2026");
      admin.set("name", "Blossom Live Team");
      admin.set("verified", true);
      app.save(admin);
    }
  },
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    users.createRule = "";
    app.save(users);
    try {
      const admin = app.findAuthRecordByEmail("users", "team@blossomlive.in");
      app.delete(admin);
    } catch (e) {
      if (e.message.includes("no rows in result set")) return;
      throw e;
    }
  },
);
