/// <reference path="../pb_data/types.d.ts" />

// Generates the public project ID (BL-DDMMYY-###) server-side on every
// new submission, so clients can never collide or spoof it.
onRecordCreateRequest((e) => {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, "0");
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const yy = String(now.getFullYear()).slice(-2);
  const prefix = "BL-" + dd + mm + yy + "-";

  let seq = 1;
  try {
    const todays = $app.findRecordsByFilter(
      "submissions",
      "project_id ~ {:prefix}",
      "-created",
      1,
      0,
      { prefix: prefix },
    );
    if (todays.length > 0) {
      const last = todays[0].getString("project_id");
      const parts = last.split("-");
      const n = parseInt(parts[2], 10);
      if (!isNaN(n)) seq = n + 1;
    }
  } catch (err) {
    $app.logger().warn("project id sequence lookup failed", "err", String(err));
  }

  e.record.set("project_id", prefix + String(seq).padStart(3, "0"));
  if (!e.record.get("status")) {
    e.record.set("status", "new");
  }

  e.next();
}, "submissions");
