/// <reference path="../pb_data/types.d.ts" />

// Sends the confirmation email with the project ID after a submission lands.
onRecordAfterCreateSuccess((e) => {
  const email = e.record.getString("email");
  const name = e.record.getString("name") || "there";
  const projectId = e.record.getString("project_id");

  if (!email) {
    e.next();
    return;
  }

  const message = new MailerMessage({
    from: { name: "Blossom Live" },
    to: [{ address: email }],
    subject: "We've got it — your Greenprint is underway (" + projectId + ")",
    html:
      '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;color:#2C2C2C">' +
      '<h1 style="color:#1B4D3E;font-size:24px">We\'ve got it, ' + name + '.</h1>' +
      '<p style="font-size:15px;line-height:1.6">Your space is officially in our hands. ' +
      'Your project ID is <strong style="color:#1B4D3E">' + projectId + '</strong> — keep it handy for anything you ask us about this project.</p>' +
      '<p style="font-size:15px;line-height:1.6">A real human on our team — not a bot — will review your photos, dimensions, and vision, ' +
      'and send you a personalized <strong>Greenprint</strong> within <strong>48 hours</strong>.</p>' +
      '<p style="font-size:15px;line-height:1.6">Your Greenprint includes a layout direction, a plant palette matched to your light and climate, ' +
      'and an honest cost estimate within your budget range.</p>' +
      '<p style="font-size:15px;line-height:1.6">Talk soon,<br/>The Blossom Live team</p>' +
      '<hr style="border:none;border-top:1px solid #e5e0d8;margin:24px 0"/>' +
      '<p style="font-size:12px;color:#8B8680">Blossom Live — beautiful is not enough, it has to work.</p>' +
      "</div>",
  });

  try {
    $app.newMailClient().send(message);
  } catch (err) {
    $app.logger().error(
      "submission confirmation email failed",
      "to", email,
      "project", projectId,
      "err", String(err),
    );
  }

  e.next();
}, "submissions");
